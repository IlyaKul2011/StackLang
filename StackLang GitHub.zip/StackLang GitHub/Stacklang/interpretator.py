import os, time
def strtobool(str):
	if str == 'True':
		return True
	if str == 'False':
		return False


def get_all_files(directory):
    all_files = []
    for dirpath, dirnames, filenames in os.walk(directory):
        for filename in filenames:
            all_files.append(os.path.join(dirpath, filename))
    return all_files
def interpretator(
code = None,
file = None, 
stack = [],
namespace = {}, 
macroses = {}, 
mode = 'normal', 
strings = []):
  	
	
	if code == None:
		with open(file, "r") as f:
				code = f.read()
	elif file == None:
		code = code
	
	strings = code.split('\n')
	
	clause = []
	
	multistring = ''' '''
	counter = 0
	
	for string in strings:
		
							
		# Импорт макропрограмм и stl.path
		if string.startswith('include '):
			
			arg = string.replace('include ', '')
			with open(arg+'.stlmacro', "r") as f:
				macroprog = f.read()
				macroses[arg] = macroprog
		if string.startswith('include* '):
			arg = string.replace('include* ', '')
			for i in get_all_files(arg):
				with open(i, "r") as f:
					macroprog = f.read()
					macroses[i.replace('.stlmacro', '')] = macroprog
			
			
		if string == 'use stl.path':
			
			mainpath = os.getcwd()
			try:
				with open('stl.path', "r") as f:
					path = f.read()
				paths = path.split('\n')
				for p in paths:
					try:
						os.chdir(p)
					except FileNotFoundError as e:
						print('Can not access to directory:', e)
						print('Текущий каталог: ', os.getcwd())
			except FileNotFoundError:
				print('Cant find stl.path file')
		if string == 'main path':
			os.chdir(mainpath)		
		# Использование макропрограмм
		if string.startswith('$'):
			arg = string.replace('$', '')
			splitted = macroses[arg]
			interpretator(code = splitted, stack = stack, namespace = namespace)
		# Средства консольного ввода/вывода
		if string.startswith('stk '):
			stack.append(string.replace('stk ', ''))
		if string == 'print':
			arg = stack.pop()
			print(arg)
		if string == 'input':
			stack.append(input())
		if string == 'label':
			print(stack.pop(), end = '')
		if string == 'xprint':
			str = stack.pop()
			print(str)
			stack.append(str)
		if string == 'ask':
			vars = stack.pop()
			label = stack.pop()
			warning = stack.pop()
			print(label)
			c = True
			
			while c:
				i = input()
				if i in vars:
					c = False
					stack.append(i)
				else:
					print(warning)
					pass
			
		# Основные математические операции 
		if string == 'sum':
			stack.append(int(stack.pop()) + int(stack.pop()))
		if string == 'sub':
			stack.append(int(stack.pop()) - int(stack.pop()))
		if string == 'mul':
			stack.append(int(stack.pop()) * int(stack.pop()))
		if string == 'div':
			stack.append(int(stack.pop()) / int(stack.pop()))
		if string == 'more':
			stack.append(strtobool(int(stack.pop()) < int(stack.pop())))	
		if string == 'less':
			stack.append(strtobool(int(stack.pop()) > int(stack.pop())))
		if string == 'eq':
			stack.append(strtobool(int(stack.pop()) == int(stack.pop())))
			
		# Основные логические операции
		if string == 'boolify':
			stack.append(strtobool(stack.pop()))
		if string == 'not':
			stack.append(not stack.pop())
		if string == 'and':
			stack.append(stack.pop() and stack.pop())
		if string == 'or':
			stack.append(stack.pop() or stack.pop())
			
		# Действия со стеком 
		if string == 'iter':
			stack.append(stack.pop(0))
		if string == 'rst stack':
			stack = []
		if string == 'del':
			stack.pop()
			
		# Конструкция use stack...mainstack	
		if string == 'use stack':
			usestack = stack.pop()
			mainstack = stack
			stack = usestack
		if string == 'main stack':
			stack = mainstack
			stack.append(usestack)
			
		# Действия с массивами	
		if string.startswith('array '):
			args = string.replace('array ', '').split(', ')
			stack.append(args)
		if string.startswith('get '):
			index = string.replace('get ', '')
			array = stack.pop()
			gets =  array.pop(int(index))
			stack.append(gets)
			
		# Действия с буфером 
		if string == 'buf':
			buf = stack.pop()
		if string == 'unbuf':
			stack.append(buf)
		if string == 'rst buf':
			buf = None
			
		# Действия с пространствами имен
		if string.startswith('define '):
			namespace[string.replace('define ', '')] = stack.pop()
		if string == 'export':
			stack.append(namespace[stack.pop()])
		if string == 'rst namespace':
			namespace = {}

		# Функция выхода
		if string == 'exit':
			break
		# Комментарии
		if string.startswith('*') and string.endswith('*'):
			pass
		# Встроенный модуль pystk
		if string.startswith('pyexe '):
			exec(string.replace('pyexe ', ''))	
		# Средства разработчика
		if string == 'PRINT_MACROSES':
			print(macroses)
		if string == 'PRINT_STACK':
			print(stack)
		# Действия со строками
		if string == 'join':
			stack.append(stack.pop()+stack.pop())
		if string == 'array':
			stack.append(list(stack.pop()))
		if string.startswith('split'):
			stack.append(stack.pop().split(string.replace('split ', '')))
		if string == 'count':
			stack.append(int(len(stack.pop())))
		
	
		# Инструменты работы с obj и use obj...main namespace
		if string.startswith('obj '):
			stack.append({'name' : string.replace('obj ', '')})
			
		
			
		if string.startswith('getattr '):
			args = string.replace('getattr', '').split('.')
			exec(f'stack.append(stack.pop()[args[1]])')	
		if string == 'use obj':
			mainnamespace = namespace
			namespace = stack.pop()
			
		if string == 'main namespace':
			stack.append(namespace)
			namespace = mainnamespace
		
			
		if string.startswith('mode '):
			arg = string.replace('mode ', '')
			if arg == 'multistring':
				mode = 'multistring'
			if arg == 'normal':
				mode = 'normal'
			if arg == 'dynamic':
				mode = 'dynamic'
			
		if mode == 'multistring':
			
			if string == 'exitmode':
				mode = 'normal'
				stack.append(multistring.replace('mode multistring\n', ''))
			else: multistring = multistring + (string.replace('"', '') + '\n')
		
			
			
		# assoc конструкция	
		if ' assoc ' in string:
			args = string.split(' assoc ')
			macroses[args[1]] = macroses[args[0]]
			del macroses[args[0]]
			
		if string.startswith('case '):
			args = string.replace('case ', '').split(':')
			
			if stack.pop() == args[0]:
				macroses['match'] = '$'+args[1]
			else: macroses['match'] = ''
			
		
		if string.startswith('repeat '):
			cycle = ''
			args = string.replace('repeat ', '').split(':')
			for _ in range(int(args[1])):
				cycle = cycle + '$' + args[0] + '\n' 
			macroses['repeat'] = cycle
		
		
	
interpretator(code = '''
use stl.path
include* termgui



$termgui/Colors/Red
stk red
print
$termgui/Colors/Yellow
stk yellow
print
'''
	)
